

using GenericsLab;

namespace GTests
{
	public class GenericArrayListTest
	{
		private ObjectArrayList sut;
		private string s1 = "Hello";
		private string s2 = "World";
		private string s3 = "test";

		[SetUp]
		public void Setup()
		{
			sut = new ObjectArrayList();
		}

		[Test]
		public void TestNewObjectArrayList()
		{
			Assert.That(sut.Size, Is.EqualTo(0));
		}

		[Test]
		public void TestAdd()
		{
			sut.Add(s1).Add(s2).Add(s3);
			Assert.That(sut.Size, Is.EqualTo(3));
		}
		[Test]
		public void TestAddRemove()
		{
			sut.Add(s1).Add(s2).Add(s3).Add(s1).Add(s2).Add(s3);
			sut.Remove(3);
			Assert.That(sut.Size, Is.EqualTo(5));
		}
		[Test]
		public void TestAddRemoveSequenceIndexer()
		{
			sut.Add(s1).Add(s2).Add(s3).Add(s1).Add(s2).Add(s3);
			sut.Remove(3);
            Assert.That(sut[0], Is.EqualTo(s1));
			Assert.That(sut[1], Is.EqualTo(s2));
			Assert.That(sut[2], Is.EqualTo(s3));
			Assert.That(sut[3], Is.EqualTo(s2));
			Assert.That(sut[4], Is.EqualTo(s3));
		}

		[Test]
		public void TestGrowArray()
		{
			for (int i = 0; i < 30; i++)
				sut.Add(s1 + i);
			Assert.That(sut.Size, Is.EqualTo(30));
		}

		[Test]
		public void TestIndexOutOfBoundsSetter()
		{
			sut.Add(s1).Add(s2).Add(s3);
			Assert.That(() => sut[3],
				Throws.InstanceOf<ArgumentOutOfRangeException>());
		}

	}
}