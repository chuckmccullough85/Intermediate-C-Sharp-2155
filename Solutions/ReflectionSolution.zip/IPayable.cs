﻿
using Reflection;

namespace Inheritance
{
    public interface IPayable
    {
        double Pay();
    }
}
