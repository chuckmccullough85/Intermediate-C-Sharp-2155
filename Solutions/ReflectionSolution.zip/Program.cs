﻿
using Reflection;

Console.WriteLine("Reflection");

new AuthorDocumenter("").Scan();


