﻿
namespace Inheritance
{
    public interface IPayable
    {
        double Pay();
    }
}
