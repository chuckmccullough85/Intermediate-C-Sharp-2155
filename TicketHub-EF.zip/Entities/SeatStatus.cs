
namespace TicketModel
{
    public enum SeatStatus : int
    {
        Available = 0,
        Unavailable = 1,
        Sold = 2
    }
}
