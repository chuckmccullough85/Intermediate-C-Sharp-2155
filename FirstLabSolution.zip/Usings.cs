﻿global using FirstLab;
