﻿
Employee e = new("Hank", "Hill", 200, DateTime.Today);

e.Pay();
e.Pay();

Console.WriteLine($"{e.FirstName} has made {e.YtdGrossPay:c} so far this year");




